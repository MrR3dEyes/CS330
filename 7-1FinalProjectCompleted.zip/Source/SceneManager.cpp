///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used for setting up the light sources in
 *  the 3D scene. It configures a directional light (sunlight)
 *  and a point light (lamp post).
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Check that the shader manager exists before proceeding
	if (NULL != m_pShaderManager)
	{
		// Enable lighting in the shader
		m_pShaderManager->setBoolValue(g_UseLightingName, true);

		// ----------------------
		// LIGHT SOURCE 0: Moonlight/sunlight
		// This is a cool-toned, directional-style light simulating moonlight or sunlight, moonlight casts shadows so this is more so sunlight
		m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(10.0f, 20.0f, 10.0f)); // Overhead moon position
		m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.05f, 0.05f, 0.1f)); // Subtle cool ambient color
		m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.3f, 0.3f, 0.6f));  // Main bluish moonlight
		m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.2f, 0.2f, 0.4f)); // Specular highlights with a bluish tint
		m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 64.0f); // How focused the specular highlight is
		m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.3f); // How intense the specular highlights are

		// ----------------------
		// LIGHT SOURCE 1: Streetlamp
		// A warm, localized light representing a nearby streetlamp
		m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(-2.0f, 5.0f, 0.0f)); // Position near the light post
		m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.1f, 0.07f, 0.03f)); // Warm ambient glow
		m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(1.0f, 0.9f, 0.7f));  // Bright warm diffuse light
		m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(1.0f, 0.9f, 0.6f)); // Strong warm specular
		m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f); // More spread out than moonlight
		m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.6f); // Stronger specular for shiny surfaces near the lamp

		// ----------------------
		// LIGHT SOURCES 2 and 3: Help illuminate the rest of the scene 
		for (int i = 2; i < 4; ++i) {
			m_pShaderManager->setVec3Value("lightSources[" + std::to_string(i) + "].ambientColor", glm::vec3(0.0f)); // No ambient light
			m_pShaderManager->setVec3Value("lightSources[" + std::to_string(i) + "].diffuseColor", glm::vec3(0.0f)); // No diffuse light
			m_pShaderManager->setVec3Value("lightSources[" + std::to_string(i) + "].specularColor", glm::vec3(0.0f)); // No specular light
			m_pShaderManager->setFloatValue("lightSources[" + std::to_string(i) + "].focalStrength", 1.0f); // Default low value
			m_pShaderManager->setFloatValue("lightSources[" + std::to_string(i) + "].specularIntensity", 0.0f); // No specular effect
			m_pShaderManager->setVec3Value("lightSources[" + std::to_string(i) + "].position", glm::vec3(0.0f)); // Position set to origin (irrelevant since it's inactive)
		}
	}
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for defining the material properties
 *  of objects in the scene for realistic lighting effects.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL carMaterial;
	OBJECT_MATERIAL tireMaterial;
	OBJECT_MATERIAL asphaltMaterial;
	OBJECT_MATERIAL concreteMaterial;
	OBJECT_MATERIAL glassMaterial;
	OBJECT_MATERIAL metalMaterial;
	OBJECT_MATERIAL treeMaterial;

	/*** CAR BODY MATERIAL (Both white and dark cars) ***/
	carMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	carMaterial.ambientStrength = 0.3f;
	carMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	carMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	carMaterial.shininess = 64.0f;
	carMaterial.tag = "carBody";
	m_objectMaterials.push_back(carMaterial);

	/*** TIRE MATERIAL ***/
	tireMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	tireMaterial.ambientStrength = 0.2f;
	tireMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	tireMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	tireMaterial.shininess = 8.0f;  // Low shininess for rubber
	tireMaterial.tag = "tire";
	m_objectMaterials.push_back(tireMaterial);

	/*** ASPHALT MATERIAL ***/
	asphaltMaterial.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	asphaltMaterial.ambientStrength = 0.4f;
	asphaltMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	asphaltMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	asphaltMaterial.shininess = 15.0f;  // Very low shininess
	asphaltMaterial.tag = "asphalt";
	m_objectMaterials.push_back(asphaltMaterial);

	/*** CONCRETE MATERIAL ***/
	concreteMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	concreteMaterial.ambientStrength = 0.5f;
	concreteMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	concreteMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	concreteMaterial.shininess = 16.0f;
	concreteMaterial.tag = "concrete";
	m_objectMaterials.push_back(concreteMaterial);

	/*** GLASS MATERIAL (Windows) ***/
	glassMaterial.ambientColor = glm::vec3(0.1f, 0.15f, 0.2f);
	glassMaterial.ambientStrength = 0.1f;
	glassMaterial.diffuseColor = glm::vec3(0.2f, 0.3f, 0.4f);
	glassMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	glassMaterial.shininess = 128.0f;  // High shininess for glass
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);

	/*** METAL MATERIAL (Lamp post) ***/
	metalMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metalMaterial.ambientStrength = 0.3f;
	metalMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	metalMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	metalMaterial.shininess = 32.0f;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);

	/*** TREE MATERIAL ***/
	treeMaterial.ambientColor = glm::vec3(0.1f, 0.3f, 0.1f);
	treeMaterial.ambientStrength = 0.4f;
	treeMaterial.diffuseColor = glm::vec3(0.2f, 0.6f, 0.2f);
	treeMaterial.specularColor = glm::vec3(0.1f, 0.2f, 0.1f);
	treeMaterial.shininess = 8.0f;  // Low shininess for organic material
	treeMaterial.tag = "tree";
	m_objectMaterials.push_back(treeMaterial);

	/*** GRASS MATERIAL ***/
	OBJECT_MATERIAL grassMaterial;
	grassMaterial.ambientColor = glm::vec3(0.05f, 0.15f, 0.05f);    // Dark ambient
	grassMaterial.ambientStrength = 0.3f;
	grassMaterial.diffuseColor = glm::vec3(0.1f, 0.4f, 0.1f);      // Dark diffuse  
	grassMaterial.specularColor = glm::vec3(0.05f, 0.2f, 0.05f);   // Subtle shine
	grassMaterial.shininess = 16.0f;
	grassMaterial.tag = "grass";
	m_objectMaterials.push_back(grassMaterial);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadConeMesh();

	bool bReturn = false;

	bReturn = CreateGLTexture(
		"C:\\Users\\Filip\\Downloads\\CS330Content\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\Textures\\Window.jpg",
		"WindowTexture");
	if (!bReturn)
	{
		std::cerr << "Failed to load WindowTexture" << std::endl;
	}

	bReturn = CreateGLTexture(
		"C:\\Users\\Filip\\Downloads\\CS330Content\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\Textures\\WhiteMetallic.png",
		"WhiteCarBody");
	if (!bReturn)
	{
		std::cerr << "Failed to load WhiteCarBody texture" << std::endl;
	}

	bReturn = CreateGLTexture(
		"C:\\Users\\Filip\\Downloads\\CS330Content\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\Textures\\Asphalt.jpg",
		"AsphaltGround");
	if (!bReturn)
	{
		std::cerr << "Failed to load AsphaltGround texture" << std::endl;
	}

	bReturn = CreateGLTexture(
		"C:\\Users\\Filip\\Downloads\\CS330Content\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\Textures\\Concrete.jpg",
		"ConcreteBase");
	if (!bReturn)
	{
		std::cerr << "Failed to load ConcreteBase texture" << std::endl;
	}

	bReturn = CreateGLTexture(
		"C:\\Users\\Filip\\Downloads\\CS330Content\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\Textures\\Tree.jpg",
		"TreeBark");
	if (!bReturn)
	{
		std::cerr << "Failed to load TreeBark texture" << std::endl;
	}

	bReturn = CreateGLTexture(
		"C:\\Users\\Filip\\Downloads\\CS330Content\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\Textures\\Tires.jpg",
		"TireRubber");
	if (!bReturn)
	{
		std::cerr << "Failed to load TireRubber texture" << std::endl;
	}

	bReturn = CreateGLTexture(
		"C:\\Users\\Filip\\Downloads\\CS330Content\\CS330Content\\Projects\\7-1_FinalProjectMilestones\\Source\\Textures\\DarkMetal.jpg",
		"DarkCarBody");
	if (!bReturn)
	{
		std::cerr << "Failed to load DarkCarBody texture" << std::endl;
	}

	// Bind all loaded textures to texture slots (up to 16)
	BindGLTextures();
	DefineObjectMaterials();
	SetupSceneLights();
}

/***********************************************************
 *  RenderVehicleTires()
 *
 *  Renders four tires for a vehicle at specified positions
 ***********************************************************/
void SceneManager::RenderVehicleTires(glm::vec3 vehicleCenter, float globalScale,
	bool frontLeft, bool frontRight, bool rearLeft, bool rearRight,
	glm::vec3 frontOffset, glm::vec3 rearOffset,
	glm::vec3 leftOffset, glm::vec3 rightOffset)
{
	glm::vec3 scaleXYZ = glm::vec3(.5f) * globalScale;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 90.0f; // rotate torus on its side so it looks like a tire
	float ZrotationDegrees = 0.0f;

	SetTextureUVScale(0.5f, 0.50f);
	SetShaderTexture("TireRubber");
	SetShaderMaterial("tire");

	// Front Left Tire
	if (frontLeft) {
		glm::vec3 positionXYZ = (vehicleCenter + frontOffset + leftOffset) * globalScale;
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		m_basicMeshes->DrawTorusMesh();
	}

	// Front Right Tire
	if (frontRight) {
		glm::vec3 positionXYZ = (vehicleCenter + frontOffset + rightOffset) * globalScale;
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		m_basicMeshes->DrawTorusMesh();
	}

	// Rear Left Tire
	if (rearLeft) {
		glm::vec3 positionXYZ = (vehicleCenter + rearOffset + leftOffset) * globalScale;
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		m_basicMeshes->DrawTorusMesh();
	}

	// Rear Right Tire
	if (rearRight) {
		glm::vec3 positionXYZ = (vehicleCenter + rearOffset + rightOffset) * globalScale;
		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		m_basicMeshes->DrawTorusMesh();
	}

	// Reset UV scale after tire rendering
	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  RenderInfinitiG35()
 *
 *  Renders the Dark Grey Infiniti G35 with all components
 ***********************************************************/
void SceneManager::RenderInfinitiG35(float globalScale)
{
	glm::vec3 vehicleCenter = glm::vec3(-2.0f, 0.0f, 2.0f);

	// Main car body
	glm::vec3 scaleXYZ = glm::vec3(4.0f, 1.0f, 2.0f) * globalScale;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 90.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ = glm::vec3(-2.0f, 0.5f, 2.0f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("DarkCarBody");
	SetShaderMaterial("carBody");
	m_basicMeshes->DrawBoxMesh();

	// Roof
	scaleXYZ = glm::vec3(-3.0f, 0.75f, 1.85f) * globalScale;
	XrotationDegrees = 0.0f;
	YrotationDegrees = -90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.0f, 1.0f, 2.0f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("DarkCarBody");
	SetShaderMaterial("carBody");
	m_basicMeshes->DrawBoxMesh();

	// Render tires for Infiniti G35
	glm::vec3 frontOffset = glm::vec3(-1.22f, 0.25f, 0.0f);
	glm::vec3 rearOffset = glm::vec3(1.12f, 0.25f, 0.0f);
	glm::vec3 leftOffset = glm::vec3(0.0f, 0.0f, 1.0f);
	glm::vec3 rightOffset = glm::vec3(0.0f, 0.0f, -1.0f);

	RenderVehicleTires(vehicleCenter, globalScale, true, true, true, true,
		frontOffset, rearOffset, leftOffset, rightOffset);
}

/***********************************************************
 *  RenderCrownVictoria()
 *
 *  Renders the White Crown Victoria with all components
 ***********************************************************/
void SceneManager::RenderCrownVictoria(float globalScale)
{
	glm::vec3 vehicleCenter = glm::vec3(2.0f, 0.0f, 2.0f);

	// Main car body
	glm::vec3 scaleXYZ = glm::vec3(4.0f, 1.0f, 2.0f) * globalScale;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = -90.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ = glm::vec3(2.0f, 0.5f, 2.0f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("WhiteCarBody");
	SetShaderMaterial("carBody");
	m_basicMeshes->DrawBoxMesh();

	// Windshield (Front)
	scaleXYZ = glm::vec3(0.30f, 0.25f, 0.750f) * globalScale;
	XrotationDegrees = 55.0f;
	YrotationDegrees = -90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.0f, 1.45f, 3.7f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("WindowTexture");
	SetShaderMaterial("glass");
	m_basicMeshes->DrawPlaneMesh();

	// Side Window (Left)
	scaleXYZ = glm::vec3(0.25f, 0.5f, 0.50f) * globalScale / globalScale;
	XrotationDegrees = 55.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(1.25f, 1.4f, 3.55f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("WindowTexture");
	SetShaderMaterial("glass");
	m_basicMeshes->DrawPlaneMesh();

	// Side Window (Right)
	scaleXYZ = glm::vec3(0.25f, 0.5f, 0.50f) * globalScale / globalScale;
	XrotationDegrees = 55.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(2.75f, 1.4f, 3.55f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("WindowTexture");
	SetShaderMaterial("glass");
	m_basicMeshes->DrawPlaneMesh();

	// Roof
	scaleXYZ = glm::vec3(3.0f, .75f, 1.80f) * globalScale;
	XrotationDegrees = 0.0f;
	YrotationDegrees = -90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.0f, 1.4f, 2.0f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("WhiteCarBody");
	SetShaderMaterial("carBody");
	m_basicMeshes->DrawBoxMesh();

	// Hood
	scaleXYZ = glm::vec3(1.5f, 0.35f, 1.85f) * globalScale;
	XrotationDegrees = 0.0f;
	YrotationDegrees = -90.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(2.0f, 1.0f, 3.15f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("WhiteCarBody");
	SetShaderMaterial("carBody");
	m_basicMeshes->DrawBoxMesh();

	// Render tires for Crown Victoria
	glm::vec3 frontOffset = glm::vec3(1.22f, 0.25f, 0.0f);
	glm::vec3 rearOffset = glm::vec3(-1.12f, 0.25f, 0.0f);
	glm::vec3 leftOffset = glm::vec3(0.0f, 0.0f, 1.0f);
	glm::vec3 rightOffset = glm::vec3(0.0f, 0.0f, -1.0f);

	RenderVehicleTires(vehicleCenter, globalScale, true, true, true, true,
		frontOffset, rearOffset, leftOffset, rightOffset);
}

/***********************************************************
 *  RenderLampPost()
 *
 *  Renders the street lamp with all components
 ***********************************************************/
void SceneManager::RenderLampPost()
{
	// Main lamp post pole
	glm::vec3 scaleXYZ = glm::vec3(0.2f, 5.5f, 0.2f);
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ = glm::vec3(7.75f, 0.75f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawCylinderMesh();

	// Lamp top (yellow/warm light)
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f);
	positionXYZ = glm::vec3(7.75f, 6.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 0.8f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Lamp base
	scaleXYZ = glm::vec3(0.5f, 0.75f, 0.75f);
	positionXYZ = glm::vec3(7.75f, 0.05f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("ConcreteBase");
	SetShaderMaterial("concrete");
	m_basicMeshes->DrawCylinderMesh();
}

/***********************************************************
 *  RenderGrassPatch()
 *
 *  Renders a circular grass patch that fits inside the concrete torus
 ***********************************************************/
void SceneManager::RenderGrassPatch(float globalScale)
{
	glm::vec3 scaleXYZ = glm::vec3(2.05f, 0.05f, 1.6f) * globalScale;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 90.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ = glm::vec3(-6.0f, 0.01f, 0.0f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	// Remove SetShaderColor - let material handle the color
	SetShaderMaterial("grass");
	m_basicMeshes->DrawCylinderMesh();

	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  RenderTreeAndIsland()
 *
 *  Renders the tree with its concrete island holder and grass patch
 ***********************************************************/
void SceneManager::RenderTreeAndIsland(float globalScale)
{
	// Tree (Cone)
	glm::vec3 scaleXYZ = glm::vec3(1.5f, 4.0f, 1.5f);
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ = glm::vec3(-9.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderMaterial("tree");
	m_basicMeshes->DrawConeMesh();

	// Tree Island Holder (Torus) - Oval shape, smaller to avoid vehicles
	scaleXYZ = glm::vec3(2.5f, 1.8f, 0.4f) * globalScale;
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(-6.0f, 0.0f, 0.0f) * globalScale;

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("ConcreteBase");
	SetShaderMaterial("concrete");
	m_basicMeshes->DrawTorusMesh();

	RenderGrassPatch(globalScale);
}

/***********************************************************
 *  RenderGround()
 *
 *  Renders the asphalt ground plane
 ***********************************************************/
void SceneManager::RenderGround()
{
	// Ground plane with asphalt texture
	glm::vec3 scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetTextureUVScale(4.0f, 4.0f);
	SetShaderTexture("AsphaltGround");
	SetShaderMaterial("asphalt");
	m_basicMeshes->DrawPlaneMesh();

	// Reset UV scale after ground rendering
	SetTextureUVScale(1.0f, 1.0f);
}
/***********************************************************
 *  RenderSkyBackdrop()
 *
 *  Renders a blue sky backdrop behind the scene
 ***********************************************************/
void SceneManager::RenderSkyBackdrop()
{
	// Large vertical plane positioned far behind the scene
	glm::vec3 scaleXYZ = glm::vec3(120.0f, 120.0f, 180.0f);  // Much larger coverage
	float XrotationDegrees = 45.0f;
	float YrotationDegrees = 90.0f;
	float ZrotationDegrees = 90.0f;
	glm::vec3 positionXYZ = glm::vec3(0.0f, 25.0f, -25.0f);  // Higher and further back

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderColor(0.3f, 0.6f, 0.9f, 1.0f);
	m_basicMeshes->DrawPlaneMesh();

	SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes using
 *  organized custom functions
 ***********************************************************/
void SceneManager::RenderScene()
{
	float globalScale = 1.5f;

	// Render sky first (back to front rendering)
	RenderSkyBackdrop();

	// Render all scene components
	RenderGround();
	RenderTreeAndIsland(globalScale);
	RenderInfinitiG35(globalScale);
	RenderCrownVictoria(globalScale);
	RenderLampPost();
}